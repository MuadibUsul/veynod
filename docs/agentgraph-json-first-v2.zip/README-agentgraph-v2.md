# AgentGraph — JSON-first homepage

## Principle
The API response **is** the brand identity. No hero, no product cards, no network graph, no conventional navigation.

## Files
- `agentgraph-json-home-v2.html`: optional human-facing styled JSON representation, with copy and linked paths.
- `agentgraph-json-home-v2.json`: actual machine-readable JSON, unchanged from the screenshot.
- `agentgraph-json-v2-desktop.png`, `agentgraph-json-v2-mobile.png`: previews.

## HTTP truth
There is a technical distinction between looking like JSON and actually returning JSON:

1. If `/` responds with `Content-Type: application/json`, browsers control the rendering; the site cannot dictate colors, fonts, hover states or cursor animations.
2. If `/` responds with `Content-Type: text/html`, this styled prototype works, but it is a JSON **viewer**, not itself a JSON response.
3. Recommended hybrid: use HTTP `Accept` content negotiation. Return HTML for a request explicitly preferring `text/html`; return real JSON for `Accept: application/json` or generic API clients. Keep `Vary: Accept`, disable inappropriate response caching, and preserve the original JSON payload schema. A separate raw endpoint is an alternative.

## Production notes
- Replace the hardcoded sample payload with the server's current metadata. Do not assert hardcoded health/status as live data.
- Preserve existing `/dashboard/`, `/v1`, `/mcp/`, `/healthz`, `/v1/agent-docs` as routes, if the application supports them.
- Keep all user-facing links same-origin and check their actual behavior before release.
- If the concept is strictly **JSON as the root HTTP response**, serve `.json` and treat the HTML as a design study or a separate documentation route.
